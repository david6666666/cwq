SELECT * FROM emp;
-- 指定字段进行查询
SELECT empno,job,ename FROM emp;
-- 查询所有员工的年薪
SELECT ename, sal*12 as year_sal FROM emp;
-- 去重
SELECT DISTINCT deptno from emp
-- 查询员工，按照月薪从低到高排序
SELECT ename ,sal from emp ORDER BY sal 
SELECT ename, sal FROM emp WHERE sal>1000 and sal<2000 ORDER BY sal
-- 分页查询,返回上万行结果，返回的结果存在内存，内存溢出，数据库崩溃
SELECT * from emp LIMIT 0,5;

-- 统计一共有多少员工
SELECT count(empno) from emp;
SELECT empno,sal FROM emp WHERE sal = (SELECT max(sal) from emp);

-- 字符串连接
SELECT CONCAT(ename,'的工资是：',sal) as '工资' from emp ;
-- 字符串截取
SELECT SUBSTRING("abcedg",1,3)
-- 去除空格
SELECT RTRIM("  abcd  ")
-- 日期函数
INSERT into emp (empno,ename,hiredate) VALUES (888,'zs','2017-09-21')

分组
GROUP BY 子句将表中数据分成若干小组
•语法格式
-select column, group_function(column) 
-from table 
-[where condition]
-[group by group一by一expression] 
-[order by column];

having 过滤：	，
•对分组查词的结果避行过滤.要使用having从句
•having从句过淀分组后的结果，它只能出现在group by从句之后，而where从句要出现 在group by从句之前，
•where过滤行，having过滤分组 having支持所有where操作符•
•语法格式	I
-select column, group_function(column)
-from table -[where condition]
-(group by group_by_expression]
-[having group一condition]
-(order by column);.
执行过程：-- from -- where -- group by- having- select-- order by

-- 统计每个部门的平均工资
SELECT deptno,AVG(sal) FROM emp GROUP BY deptno

-- 存在group by 分组，select子句不能写group by没有的字段。除非用在聚合函数中

-- 统计每个部门的人数，最高工资，思低工资，平均工资
SELECT deptno,COUNT(empno),MAX(sal),min(sal),avg(sal) FROM emp GROUP BY deptno;

-- 统计每个部门的人数，最离工资，最低工资平均工资，但是排除10部门
SELECT deptno,COUNT(empno),MAX(sal),min(sal),avg(sal) FROM emp where deptno <> 10 GROUP BY deptno;

--  统计每个部门的人数，最离工资，最低工资平均工资，但是部门的平均工资小于2000的不要统计(where 子句中不能使用聚合函数)(执行顺序： from > where > GROUP BY > SELECT)
SELECT deptno,COUNT(empno),MAX(sal),min(sal),avg(sal) FROM emp  GROUP BY deptno HAVING AVG(sal) >= 2000;

-- 在emp表中，列出工资居小值小于2000的职位 
SELECT job, min(sal)FROM emp GROUP BY job HAVING min(sal) <2000

-- 统计人数小于4的部门的平均工资.
SELECT deptno,count(1) FROM emp GROUP BY deptno HAVING count(1)<4


 
