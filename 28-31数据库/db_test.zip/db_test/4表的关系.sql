-- 建立学生表，成绩表，课程表
 CREATE TABLE student1(
 id int PRIMARY KEY,
 name VARCHAR(200) not NULL,
 age int);
 
 CREATE TABLE subject1(
 id int PRIMARY KEY,
 name VARCHAR(200) not NULL);
 
 CREATE TABLE score1(
 id int PRIMARY KEY,
 score int,
 s_id int,
 sub_id int,
 CONSTRAINT FOREIGN key (s_id) REFERENCES student1 (id),
 CONSTRAINT FOREIGN key (sub_id) REFERENCES subject1 (id));