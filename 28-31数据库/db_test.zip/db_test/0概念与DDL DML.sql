-网状数据库	
-层次数据库
-关系数据库	（一般来说都是基于磁盘的，读写速度不快）
•采用关系•(二维表）结构賭存与管理数据
	•采用结构化査询语言（SQL )作为客户端锃数据库服务器间沟通的桥梁 	•目前主流的数据库技术.
-对象数据库
•把面向对象的方法和数据库技术结合起来可以使数据库系统的分析、设 计晶大程度地与人们对客观世界的认识相一致

-NOSQL数据库	（一般放内存里，所以速度快）
•Not Only SQL数据库泛指非关系数据库•如MongoDB •关系数据库在超大规模和高并发的web2.0纯动态网站已经显得力不从
心，暴露了很多难以克服的问题。NOSQL数据库的产生就是为了解决大规模数 据集合多重数据种类带来的挑战，尤其是大数据应用难题.

《MyCat》是代替昂贵的oracle的MySQL集群中间件。

SQL语言的分类
-- DQL(数据查询语言〉 select
-- DML (数据操作语言）Insert、update、delete
-- DDL (舰定义语言） create、alter/ drop
-- DCL (数据控制语言） grant, revoke
-- TCL(事务与制语言）SAVEPOINT、ROLLBACK、SETTRANSACTION,COMMIT

DDL(数据定义语言)
表操作
-- 创建表
CREATE table t_student 
(id int(4) PRIMARY KEY,
 sname VARCHAR(2000) not null ,
 address VARCHAR(200));
 
 DESC t_student
 
-- 删除表
DROP TABLE t_sudent

-- 修改表
alter table 表名 add | change | drop | nodify 列名 类型

-- 在t_student 中添加一个新字段

ALTER TABLE t_student add sex int(1) DEFAULT 0

数据操作（DML，DQL）

SELECT * FROM t_student
-- 全部字段插入
INSERT into t_student VALUES(1,'张三','北京',0);
-- 选择几个字段插入
INSERT into t_student (id,sname) VALUES(2,'ls')
-- 一次性插入多行

INSERT into t_student (id,sname) VALUES(3,'ww'),(4,'zz')
-- 碰到某个字段是自增的
ALTER TABLE t_student MODIFY id int(4) auto_increment;

INSERT into t_student VALUES(0,'ss','shanghai',1);

-- 把id=5的记录中地址改成广州

UPDATE t_student set address='广州' WHERE id=5

-- 删除地址为北京的所有学生

DELETE FROM t_student WHERE address='北京' 



