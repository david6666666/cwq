内连接：
SELECT ename,dname from emp ,dept WHERE emp.deptno=dept.deptno

SELECT ename,dname from emp inner join dept on emp.deptno=dept.deptno

-- 列出员工姓名，工资和工资顶级编号
SELECT ename ,sal ,grade from emp,salgrade WHERE emp.sal >salgrade.losal and emp.sal < salgrade.hisal

-- 查询员工的编号，姓名，领导的编号和姓名
SELECT e1.empno ,e1.ename ,e2.empno as mgno ,e2.ename as mgname from emp as e1 ,emp as e2 WHERE e1.mgr = e2.empno

-- 查询所有用户的姓名，部门编号和部门名称
SELECT emp.ename,emp.deptno, dept.dname from  emp ,dept WHERE emp.deptno = dept.deptno


外连接：
-左外连接
•两个表在连接过程中除返回满足连接条件的行以外，还返回左表中不满足条件的 行.这种连接称为左外联接.
-右外连接
•两个表在连接过程中除返回满足连接条件的行以外，还返回右表中不满足条件的 行，这种连接称为右外联接•
-全外连接
•两个表在连接过程中除返回满足连接条件的行以外.还返回两个表中不满足条件的 所有行.这种连接称为满外联接•
-- 查询所有部门的部门名字和该部门下的员工名字如果该部门没有员工也要列出部门名字

SELECT emp.ename, dept.dname from emp right join dept on emp.deptno = dept.deptno
-- using(字段)  连接的条件，并且两个表之间的字段名字相同
SELECT emp.ename, dept.dname from emp right join dept USING (deptno)