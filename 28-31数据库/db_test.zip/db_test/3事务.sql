事务 我们可以理解成一个锁
CREATE TABLE t_account
(
id int PRIMARY KEY,
money DOUBLE
)

BEGIN  -- 开启
UPDATE t_account set money=money-100 WHERE id=1
UPDATE t_account set money=money+100 WHERE id=2
COMMIT -- 提交
ROLLBACK -- 回滚