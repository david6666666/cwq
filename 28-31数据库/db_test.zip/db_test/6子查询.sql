子查询可以在select, FROM,WHERE

单行子查询 
-可以用运算符
-- 如何查得所有比“CLARK”工资高的员工信息
SELECT * FROM emp
WHERE sal>(SELECT sal FROM emp WHERE ename='CLARK');

-- 査询工资高于平均工资的雇员名字和工资。
SELECT ename ,sal FROM emp
WHERE sal > (SELECT AVG(sal) FROM emp);

-- 査询和SCOTT同一部门且比他工资低的雇员名字和工资。
SELECT ename, sal FROM emp WHERE sal<(SELECT sal FROM emp WHERE ename='SCOTT') and deptno = (SELECT deptno FROM emp WHERE ename='SCOTT');

多行子查询
-多行子查词返回多行记录 
-对多行子査间只能使用多行记录比较运算符 
	ALL和子查询返回的所有值比较
	ANY和子查词返回的任意一个值 
	IN等于列表中的任何一个

-- 查询工资低于任何一个“CLERK”的工资的雇员信息
SELECT * from emp WHERE sal < ALL (SELECT sal from emp WHERE job='CLERK');

-- 查询部门20中职务同部门10的雇员一样的雇员信息
SELECT * FROM emp WHERE job In (SELECT job FROM emp WHERE deptno=10) and deptno=20;

-- 查询毎个部门的详细信息及该部门平均工资和等级
SELECT t3.*,t4.grade from  (SELECT t2.* ,avg(t1.sal) as avg_sal FROM emp as t1 right join dept as t2 using (deptno) GROUP BY t2.deptno) as t3 left join salgrade as t4 on t3.avg_sal BETWEEN t4.losal and t4.hisal